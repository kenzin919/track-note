# Track Note v4 Cloud

公開用Webアプリ + Supabase接続版。

## 1. Supabase
1. Supabaseプロジェクトを作成
2. SQL Editorで `supabase_schema_v4.sql` を実行
3. Storageで `avatars` バケットを作成
4. Authentication > Providers で Emailを有効化

## 2. 接続情報
index.html 冒頭の
window.TRACK_NOTE_CONFIG
に Supabase Project URL と Publishable/anon key を設定。

service_role key は絶対に公開しない。

## 3. 公開
index.html と manifest / sw.js / icon等をCloudflare PagesやGitHub Pagesへ配置。

## 注意
このv4はクラウドログイン・プロフィール・練習・大会結果の同期を実装する土台です。
グループの他ユーザー記録を安全に共有するには、次工程でgroups/group_membersとRLSを追加します。
